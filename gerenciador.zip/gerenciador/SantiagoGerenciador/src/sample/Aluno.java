package sample;

public final class Aluno extends Pessoal {

    //atributos
    private String matricula;
    private String media;

    //get set
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }


    //to string
    @Override
    public String toString() {
        return "Aluno{" +
                "matricula='" + matricula + '\'' +
                ", media='" + media + '\'' +
                '}';
    }
}
